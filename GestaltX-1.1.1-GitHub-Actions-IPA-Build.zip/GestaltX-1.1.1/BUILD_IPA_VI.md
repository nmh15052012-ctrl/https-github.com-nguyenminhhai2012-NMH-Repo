# Build IPA bằng GitHub Actions (tiếng Việt)

Workflow `.github/workflows/build.yml` sẽ build ứng dụng trên runner macOS có Xcode, biên dịch thư viện Rust cho iOS/device simulator, sau đó đóng gói IPA và tải IPA lên GitHub Actions Artifacts.

## Cách chạy

1. Tạo một repository GitHub của bạn và tải toàn bộ thư mục mã nguồn này lên đó (giữ nguyên cấu trúc thư mục, đặc biệt là `.github/workflows/` và `.github/scripts/`).
2. Mở repository trên GitHub → **Actions**.
3. Chọn workflow **Build IPA** → **Run workflow**.
4. Chọn nhánh `main` (hoặc nhập branch/tag/commit cần build) → **Run workflow**.
5. Chờ job hoàn tất. Mở lần chạy vừa xong, kéo xuống **Artifacts**, tải `GestaltX-1.1.1-IPA` về và giải nén để lấy file `.ipa`.

Workflow cũng tự chạy khi có push lên nhánh `main` hoặc tag bắt đầu bằng `v`.

## Ký ứng dụng và cài đặt

Script hiện tại tạo IPA với chữ ký ad-hoc (`Signature=adhoc`) và giữ entitlement App Group cần thiết trong gói. Đây không phải chữ ký phân phối gắn với Apple Developer Team. Bạn sẽ cần dùng phương thức sideload/re-sign phù hợp (ví dụ AltStore hoặc SideStore) trước khi cài lên thiết bị. Không có chứng chỉ hay provisioning profile cá nhân nào được nhúng vào repository.

## Lưu ý

- Project đặt iOS deployment target là 26.0, do đó workflow dùng runner `macos-26` và Xcode stable.
- GitHub Actions phải được bật trong **Settings → Actions → General**.
- Workflow này chỉ build và xuất IPA; nó không tự cài ứng dụng lên iPhone và không xác nhận các thay đổi MobileGestalt có hiệu lực trên thiết bị.
- Nếu build thất bại, mở log của job **Build IPA** và xem bước đầu tiên báo lỗi. Không chia sẻ certificate, private key hoặc provisioning profile bí mật trong log hay repository công khai.
