# GestaltX 1.1.1 — Apply verification patch

This source patch addresses a consistency issue in the Apply pipeline:

1. After writing the device plist, the app parses the bytes read back from disk.
2. It verifies the parsed document against the staged configuration.
3. The returned snapshot now stores that parsed readback document, rather than retaining the staged in-memory object.
4. GestaltManager performs a second guard before displaying Apply success and marking a device restart as pending.
5. A regression assertion checks that the committed snapshot matches a fresh read.

The existing MobileGestalt access/write mechanism and NeoSpring implementation were not expanded or altered in this patch. The patch does not bypass iOS signing, entitlements, OS-version restrictions, or device protections.

## Build and validation

This archive contains the modified Xcode source project, not a prebuilt IPA. Building/signing an iOS app requires Xcode on macOS and the appropriate signing configuration. This environment does not include `xcodebuild`, so an IPA build and on-device Respring test could not be performed here.
